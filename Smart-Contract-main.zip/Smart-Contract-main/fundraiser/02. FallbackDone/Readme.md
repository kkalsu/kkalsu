Up to fallback() function implementation done.
